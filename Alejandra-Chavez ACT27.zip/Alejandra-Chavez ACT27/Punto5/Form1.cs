﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Punto5
{
    public partial class Form1 : Form
    {
        /*Actividad 5: Configuración de Suscripción
Problema:
Una aplicación ofrece distintos niveles de suscripción.
Requisitos:
● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
técnico&quot;, &quot;Acceso anticipado&quot;).
● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
plan y los servicios elegidos.*/

        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (checkBox1.Checked == true)
            {
                label4.Text = "Soporte Tecnico";
            }
            else
            {
                if (checkBox2.Checked == true)
                {
                    label4.Text = "Acceso Anticipado";
                }
            }
            label5.Text = comboBox1.Text;
        }
    }
}
