﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto2
{
    public partial class Form1 : Form
    {
        /*Actividad 2: Encuesta de Preferencias de Música
Problema:
Una aplicación quiere conocer los gustos musicales de los usuarios.
Requisitos:
● Mostrar un ComboBox con 5 géneros musicales distintos.
● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
&quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
seleccionado y las actividades marcadas.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                label5.Text = "Jazz";
            }
            if (checkBox2.Checked == true)
            {
                label5.Text = "Rock";
            }
            if (checkBox3.Checked == true)
            {
                label5.Text = "Musica Electronica";
            }
            if (checkBox4.Checked == true)
            {
                label5.Text = "Metal";
            }
            if (checkBox5.Checked == true)
            {
                label5.Text = "Pop";
            }


            if (checkBox6.Checked == true)
            {
                label6.Text = "Escuchar en vivo";
            }
            if (checkBox7.Checked == true)
            {
                label6.Text = "Escuchar en streaming";
            }
            if (checkBox8.Checked == true)
            {
                label6.Text = "Comprar discos";
            }
        }
    }
}
